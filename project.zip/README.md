# Game Translate (Inggris -> Indonesia)

Aplikasi pribadi: tombol melayang di atas game. Tekan, layar dibaca (OCR), diterjemahkan lewat DeepL, hasilnya tampil menimpa teks asli. Tanpa iklan, tanpa langganan.

## Cara membuat APK (lewat GitHub, cukup dari browser)

1. Buat akun dan repo baru di github.com (boleh private).
2. Di repo: **Add file > Upload files**, pilih `project.zip` (jangan diekstrak), lalu **Commit changes**.
3. Di repo: **Add file > Create new file**. Di kolom nama ketik `.github/workflows/build.yml`, tempel isi file `build.yml`, lalu **Commit changes**.
4. Buka tab **Actions**. Tunggu build selesai (sekitar 3-6 menit, tanda centang hijau).
5. Klik hasil build-nya, di bagian **Artifacts** unduh `GameTranslate-APK`. Ekstrak zip-nya, di dalamnya ada `app-debug.apk`.
6. Install APK (izinkan "install dari sumber ini" kalau diminta).

Kalau build gagal (tanda silang merah), buka log-nya dan kirim pesan error-nya ke aku.

## Cara pakai

1. Daftar DeepL API Free di deepl.com, salin API key (berakhiran `:fx`).
2. Buka aplikasi, tempel API key, tekan **Simpan API key**. Tombol **Cek kuota DeepL** menampilkan sisa kuota.
3. Tekan **Mulai tombol terjemah**:
   - aktifkan izin "Tampil di atas aplikasi lain",
   - izinkan rekam layar dan pilih **seluruh layar**.
4. Buka game. Tekan tombol bulat **ID** untuk menerjemahkan, tekan **X** untuk menutup hasil. Tombol bisa digeser.
5. Untuk berhenti: tombol **Hentikan** di aplikasi, atau **Berhenti** di notifikasi.

## Catatan

- Kuota DeepL API Free: 500.000 karakter per bulan. Teks yang sama tidak dihitung dua kali (ada cache).
- API key disimpan di HP-mu, tidak ada di dalam kode.
- Hanya membaca teks Latin (bahasa Inggris). Untuk teks bergaya sangat dekoratif, hasil OCR bisa kurang akurat.
- Kalau layar diputar (landscape), tekan tombol lagi, ukuran tangkapan menyesuaikan otomatis.
