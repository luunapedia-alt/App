package com.joki.gametranslate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Menampilkan tombol melayang. Saat ditekan: tangkap layar -> OCR (ML Kit) ->
 * terjemahkan (DeepL) -> tampilkan hasil di atas teks asli.
 */
public class TranslateService extends Service {

    static final String ACTION_STOP = "com.joki.gametranslate.STOP";
    private static final String CHANNEL_ID = "gt_channel";
    private static final int NOTIF_ID = 1;
    private static final int MAX_BLOCKS = 50; // batas teks per permintaan DeepL

    private WindowManager wm;
    private Handler main;
    private ExecutorService executor;
    private TextRecognizer recognizer;
    private float density;

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private ImageReader reader;
    private VirtualDisplay display;
    private int capW, capH, capDpi;
    private Bitmap lastFrame;

    private TextView button;
    private WindowManager.LayoutParams buttonLp;
    private FrameLayout resultLayer;

    private boolean busy = false;
    private boolean started = false;

    // Cache terjemahan supaya teks yang sama tidak memakai kuota lagi (hanya dipakai di thread executor)
    private final Map<String, String> cache = new LinkedHashMap<String, String>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 500;
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        main = new Handler(Looper.getMainLooper());
        executor = Executors.newSingleThreadExecutor();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        density = getResources().getDisplayMetrics().density;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        if (projection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        projectionCallback = new MediaProjection.Callback() {
            @Override
            public void onStop() {
                main.post(() -> stopSelf());
            }
        };
        projection.registerCallback(projectionCallback, main);

        setupCapture();
        showButton();
        started = true;
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Game Translate",
                NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        Intent stop = new Intent(this, TranslateService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action act = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", pi).build();

        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Game Translate aktif")
                .setContentText("Tekan tombol 'ID' di atas game")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .addAction(act)
                .setOngoing(true)
                .build();
    }

    // ---------------------------------------------------------------- tangkap layar

    private int[] readMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        DisplayManager dmg = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display d = dmg.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels, dm.densityDpi};
    }

    private void setupCapture() {
        int[] m = readMetrics();
        capW = m[0];
        capH = m[1];
        capDpi = m[2];
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("GameTranslate", capW, capH, capDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    /** Menyesuaikan ukuran capture kalau layar diputar. Return true jika ukuran berubah. */
    private boolean syncSize() {
        int[] m = readMetrics();
        if (m[0] == capW && m[1] == capH) return false;
        capW = m[0];
        capH = m[1];
        capDpi = m[2];
        ImageReader old = reader;
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        display.resize(capW, capH, capDpi);
        display.setSurface(reader.getSurface());
        old.close();
        lastFrame = null;
        return true;
    }

    /** Dipanggil di thread executor. Kalau tidak ada frame baru, pakai frame terakhir. */
    private Bitmap grabFrame() {
        Image img = null;
        try {
            img = reader.acquireLatestImage();
        } catch (Exception ignored) {
        }
        if (img == null) return lastFrame;
        try {
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int pixelStride = p.getPixelStride();
            int rowStride = p.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();
            int padW = rowStride / pixelStride;
            Bitmap full = Bitmap.createBitmap(padW, h, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            Bitmap out = (padW == w) ? full : Bitmap.createBitmap(full, 0, 0, w, h);
            lastFrame = out;
            return out;
        } catch (Exception e) {
            return lastFrame;
        } finally {
            img.close();
        }
    }

    // ---------------------------------------------------------------- tombol melayang

    private void showButton() {
        button = new TextView(this);
        button.setText("ID");
        button.setGravity(Gravity.CENTER);
        button.setTextColor(0xFFFFFFFF);
        button.setTextSize(14);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC1565C0);
        button.setBackground(bg);

        int size = dp(52);
        buttonLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        buttonLp.gravity = Gravity.TOP | Gravity.START;
        buttonLp.x = dp(20);
        buttonLp.y = dp(200);

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        button.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = buttonLp.x;
                        startY = buttonLp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            buttonLp.x = startX + (int) dx;
                            buttonLp.y = startY + (int) dy;
                            wm.updateViewLayout(button, buttonLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) onButtonClick();
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(button, buttonLp);
    }

    private void onButtonClick() {
        if (busy) return;
        if (resultLayer != null) {
            clearResult();
            return;
        }
        busy = true;
        button.setText("...");
        button.setVisibility(View.INVISIBLE); // sembunyikan tombol supaya tidak ikut terbaca OCR
        boolean resized = syncSize();
        main.postDelayed(this::captureAndProcess, resized ? 500 : 200);
    }

    private void captureAndProcess() {
        executor.execute(() -> {
            Bitmap bmp = grabFrame();
            main.post(() -> {
                button.setVisibility(View.VISIBLE);
                if (bmp == null) {
                    finish("Belum ada gambar, coba lagi");
                    return;
                }
                runOcr(bmp);
            });
        });
    }

    // ---------------------------------------------------------------- OCR + terjemah

    private void runOcr(Bitmap bmp) {
        InputImage image = InputImage.fromBitmap(bmp, 0);
        recognizer.process(image)
                .addOnSuccessListener(text -> handleText(text))
                .addOnFailureListener(e -> finish("OCR gagal: " + e.getMessage()));
    }

    private static boolean hasLetters(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.isLetter(s.charAt(i))) return true;
        }
        return false;
    }

    private void handleText(Text text) {
        final List<String> srcs = new ArrayList<>();
        final List<Rect> boxes = new ArrayList<>();
        final List<Integer> lineCounts = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            if (srcs.size() >= MAX_BLOCKS) break;
            String t = b.getText().replace('\n', ' ').trim();
            Rect r = b.getBoundingBox();
            if (r == null || t.length() < 2 || !hasLetters(t)) continue;
            srcs.add(t);
            boxes.add(r);
            lineCounts.add(b.getLines().size());
        }
        if (srcs.isEmpty()) {
            finish("Tidak ada teks terdeteksi");
            return;
        }
        final String key = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.KEY_API, "").trim();
        if (key.isEmpty()) {
            finish("API key DeepL belum diisi");
            return;
        }
        executor.execute(() -> {
            try {
                List<String> out = translateWithCache(key, srcs);
                main.post(() -> showResults(boxes, out, lineCounts));
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "Gagal menerjemahkan" : e.getMessage();
                main.post(() -> finish(msg));
            }
        });
    }

    private List<String> translateWithCache(String key, List<String> srcs) throws Exception {
        List<String> result = new ArrayList<>(Collections.nCopies(srcs.size(), (String) null));
        List<String> toSend = new ArrayList<>();
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < srcs.size(); i++) {
            String c = cache.get(srcs.get(i));
            if (c != null) {
                result.set(i, c);
            } else {
                toSend.add(srcs.get(i));
                idx.add(i);
            }
        }
        if (!toSend.isEmpty()) {
            List<String> tr = DeepLClient.translate(key, toSend);
            for (int j = 0; j < toSend.size() && j < tr.size(); j++) {
                result.set(idx.get(j), tr.get(j));
                cache.put(toSend.get(j), tr.get(j));
            }
        }
        return result;
    }

    // ---------------------------------------------------------------- tampilkan hasil

    private void showResults(List<Rect> boxes, List<String> out, List<Integer> lineCounts) {
        clearResult();
        FrameLayout layer = new FrameLayout(this);
        for (int i = 0; i < boxes.size(); i++) {
            String t = out.get(i);
            if (t == null || t.isEmpty()) continue;
            Rect r = boxes.get(i);

            TextView tv = new TextView(this);
            tv.setText(t);
            tv.setTextColor(0xFFFFFFFF);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6101820);
            bg.setCornerRadius(dp(4));
            tv.setBackground(bg);
            tv.setPadding(dp(4), dp(2), dp(4), dp(2));

            float lineH = r.height() / (float) Math.max(1, lineCounts.get(i));
            float size = lineH * 0.62f;
            size = Math.max(dp(10), Math.min(size, dp(30)));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);

            int left = Math.max(0, r.left);
            int top = Math.max(0, r.top);
            int width = Math.max(dp(40), Math.min(r.width() + dp(8), capW - left));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = left;
            lp.topMargin = top;
            layer.addView(tv, lp);
        }

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(layer, lp);
        resultLayer = layer;

        // Pasang ulang tombol supaya tetap berada di atas hasil terjemahan
        try {
            wm.removeView(button);
            wm.addView(button, buttonLp);
        } catch (Exception ignored) {
        }
        busy = false;
        button.setText("X");
    }

    private void clearResult() {
        if (resultLayer != null) {
            try {
                wm.removeView(resultLayer);
            } catch (Exception ignored) {
            }
            resultLayer = null;
        }
        if (button != null) button.setText("ID");
    }

    private void finish(String msg) {
        busy = false;
        if (button != null) button.setText(resultLayer != null ? "X" : "ID");
        if (msg != null) Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(float v) {
        return (int) (v * density + 0.5f);
    }

    // ---------------------------------------------------------------- bersih-bersih

    @Override
    public void onDestroy() {
        try {
            if (button != null) wm.removeView(button);
        } catch (Exception ignored) {
        }
        clearResult();
        try {
            if (display != null) display.release();
            if (reader != null) reader.close();
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Exception ignored) {
        }
        recognizer.close();
        executor.shutdownNow();
        super.onDestroy();
    }
}
