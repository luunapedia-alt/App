package com.joki.gametranslate;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Klien DeepL sederhana (tanpa library tambahan). Inggris -> Indonesia. */
final class DeepLClient {

    private DeepLClient() {}

    private static String base(String key) {
        // Key gratis berakhiran ":fx" dan memakai server api-free
        return key.endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";
    }

    static List<String> translate(String key, List<String> texts) throws Exception {
        key = key.trim();
        JSONObject body = new JSONObject();
        body.put("text", new JSONArray(texts));
        body.put("source_lang", "EN");
        body.put("target_lang", "ID");
        String resp = request(key, "POST", "/v2/translate", body.toString());
        JSONArray arr = new JSONObject(resp).getJSONArray("translations");
        List<String> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            out.add(arr.getJSONObject(i).getString("text"));
        }
        return out;
    }

    /** Mengembalikan {karakter terpakai, batas karakter}. */
    static long[] usage(String key) throws Exception {
        key = key.trim();
        String resp = request(key, "GET", "/v2/usage", null);
        JSONObject o = new JSONObject(resp);
        return new long[]{o.getLong("character_count"), o.getLong("character_limit")};
    }

    private static String request(String key, String method, String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(base(key) + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", "DeepL-Auth-Key " + key);
        c.setRequestProperty("User-Agent", "GameTranslate/1.0");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code;
        try {
            code = c.getResponseCode();
        } catch (IOException e) {
            throw new Exception("Tidak bisa terhubung ke internet");
        }
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        String text = is == null ? "" : readAll(is);
        c.disconnect();
        if (code == 200) return text;
        if (code == 403) throw new Exception("API key DeepL salah");
        if (code == 456) throw new Exception("Kuota DeepL bulan ini habis");
        if (code == 429) throw new Exception("Terlalu cepat, coba lagi sebentar");
        throw new Exception("DeepL error " + code);
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
        is.close();
        return bos.toString("UTF-8");
    }
}
