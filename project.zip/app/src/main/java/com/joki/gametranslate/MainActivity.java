package com.joki.gametranslate;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    static final String PREFS = "cfg";
    static final String KEY_API = "apikey";
    static final String KEY_LANG = "lang";

    private static final int REQ_PROJECTION = 100;
    private static final int REQ_NOTIF = 101;

    private EditText keyInput;
    private TextView usageText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (16 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView info = new TextView(this);
        info.setTextSize(15);
        info.setText("Terjemahan layar game: Inggris -> Indonesia (DeepL).\n\n"
                + "1. Isi API key DeepL, lalu Simpan.\n"
                + "2. Tekan Mulai. Izinkan 'tampil di atas aplikasi lain', lalu izinkan rekam layar (pilih SELURUH LAYAR).\n"
                + "3. Buka game. Tekan tombol bulat 'ID' untuk menerjemahkan. Tekan lagi (tombol 'X') untuk menutup hasil.\n"
                + "4. Tombol bisa digeser ke mana saja.");
        root.addView(info);

        keyInput = new EditText(this);
        keyInput.setHint("API key DeepL (berakhiran :fx)");
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        keyInput.setText(prefs().getString(KEY_API, ""));
        root.addView(keyInput);

        TextView langLabel = new TextView(this);
        langLabel.setText("Bahasa game:");
        langLabel.setPadding(0, (int) (8 * d), 0, 0);
        root.addView(langLabel);

        final String[] langNames = {"Inggris", "Jepang"};
        final String[] langCodes = {"EN", "JA"};
        Spinner langSpinner = new Spinner(this);
        langSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, langNames));
        langSpinner.setSelection("JA".equals(prefs().getString(KEY_LANG, "EN")) ? 1 : 0);
        langSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                prefs().edit().putString(KEY_LANG, langCodes[pos]).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(langSpinner);

        root.addView(makeButton("Simpan API key", v -> {
            saveKey();
            toast("API key disimpan");
        }));

        root.addView(makeButton("Cek kuota DeepL", v -> checkUsage()));

        usageText = new TextView(this);
        usageText.setPadding(0, (int) (4 * d), 0, (int) (12 * d));
        root.addView(usageText);

        root.addView(makeButton("Mulai tombol terjemah", v -> start()));

        root.addView(makeButton("Hentikan", v -> {
            stopService(new Intent(this, TranslateService.class));
            toast("Dihentikan");
        }));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    private Button makeButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private String currentKey() {
        return keyInput.getText().toString().trim();
    }

    private void saveKey() {
        prefs().edit().putString(KEY_API, currentKey()).apply();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void checkUsage() {
        final String key = currentKey();
        if (key.isEmpty()) {
            toast("Isi API key dulu");
            return;
        }
        saveKey();
        usageText.setText("Mengecek...");
        new Thread(() -> {
            String msg;
            try {
                long[] u = DeepLClient.usage(key);
                msg = String.format(new Locale("id", "ID"), "Terpakai %,d dari %,d karakter", u[0], u[1]);
            } catch (Exception e) {
                msg = "Gagal: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> usageText.setText(m));
        }).start();
    }

    private void start() {
        saveKey();
        if (currentKey().isEmpty()) {
            toast("Isi API key DeepL dulu");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            toast("Aktifkan 'Tampil di atas aplikasi lain' untuk Game Translate, lalu kembali dan tekan Mulai lagi");
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                Intent i = new Intent(this, TranslateService.class);
                i.putExtra("resultCode", resultCode);
                i.putExtra("data", data);
                startForegroundService(i);
                toast("Tombol 'ID' sudah muncul. Silakan buka game-nya.");
                moveTaskToBack(true);
            } else {
                toast("Izin rekam layar ditolak");
            }
        }
    }
}
